package sample;

public class Aktivite {
    String aktiviteTipi;
    int AktiviteFiyati;


    public Aktivite(String aktiviteTipi, int aktiviteFiyati) {
        this.aktiviteTipi = aktiviteTipi;
        AktiviteFiyati = aktiviteFiyati;
    }

    public String getAktiviteTipi() {
        return aktiviteTipi;
    }

    public void setAktiviteTipi(String aktiviteTipi) {
        this.aktiviteTipi = aktiviteTipi;
    }

    public int getAktiviteFiyati() {
        return AktiviteFiyati;
    }

    public void setAktiviteFiyati(int aktiviteFiyati) {
        AktiviteFiyati = aktiviteFiyati;
    }
}
