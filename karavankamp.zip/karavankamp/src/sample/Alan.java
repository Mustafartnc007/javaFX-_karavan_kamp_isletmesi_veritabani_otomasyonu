package sample;

public class Alan {
    String alanTipi;
    String alanAdi;

    public Alan(String alanTipi, String alanAdi) {
        this.alanTipi = alanTipi;
        this.alanAdi = alanAdi;
    }

    public String getAlanTipi() {
        return alanTipi;
    }

    public void setAlanTipi(String alanTipi) {
        this.alanTipi = alanTipi;
    }

    public String getAlanAdi() {
        return alanAdi;
    }

    public void setAlanAdi(String alanAdi) {
        this.alanAdi = alanAdi;
    }

    @Override
    public String toString() {
        return alanAdi;
    }
}
