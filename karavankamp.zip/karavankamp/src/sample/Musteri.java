package sample;

import java.sql.Date;
import java.time.LocalDate;

public class Musteri {
    int id;
    public Alan alan;
    public String alnadi;
    String isim,soyisim;
    int yas;
    LocalDate giristarihi,cikistarihi;
    Aktivite aktivite;
    int ucret;

    public Musteri(String isim, String soyisim, int yas, LocalDate giristarihi, LocalDate cikistarihi) {
        this.isim = isim;
        this.soyisim = soyisim;
        this.yas = yas;
        this.giristarihi = giristarihi;
        this.cikistarihi = cikistarihi;
        assert false;
        this.alnadi=alan.getAlanAdi();
    }

    public Musteri(int id, Alan alan, String isim, String soyisim, int yas, LocalDate giristarihi, LocalDate cikistarihi, Aktivite aktivite, int ucret) {
        this.id = id;
        this.alan = alan;
        this.isim = isim;
        this.soyisim = soyisim;
        this.yas = yas;
        this.giristarihi = giristarihi;
        this.cikistarihi = cikistarihi;
        this.aktivite = aktivite;
        this.ucret = ucret;
    }

    public String getAlnadi() {
        return alan.getAlanAdi();
    }

    public void setAlnadi(String alnadi) {
        this.alnadi = alnadi;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIsim() {
        return isim;
    }

    public void setIsim(String isim) {
        this.isim = isim;
    }

    public String getSoyisim() {
        return soyisim;
    }

    public void setSoyisim(String soyisim) {
        this.soyisim = soyisim;
    }

    public int getYas() {
        return yas;
    }

    public void setYas(int yas) {
        this.yas = yas;
    }

    public LocalDate getGiristarihi() {
        return giristarihi;
    }

    public void setGiristarihi(LocalDate giristarihi) {
        this.giristarihi = giristarihi;
    }

    public LocalDate getCikistarihi() {
        return cikistarihi;
    }

    public void setCikistarihi(LocalDate cikistarihi) {
        this.cikistarihi = cikistarihi;
    }

    public Alan getAlan() {
        return alan;
    }

    public void setAlan(Alan alan) {
        this.alan = alan;
    }

    public Aktivite getAktivite() {
        return aktivite;
    }

    public void setAktivite(Aktivite aktivite) {
        this.aktivite = aktivite;
    }

    public int getUcret() {
        return ucret;
    }

    public void setUcret(int ucret) {
        this.ucret = ucret;
    }
}
