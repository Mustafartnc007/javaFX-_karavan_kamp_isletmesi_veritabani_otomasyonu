package sample.Controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class Giris {


    public ImageView projeGirisImg;
    public Button girisButton;


    @FXML
    public void girisAction() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("../GUI/kamp_alani_secme_formu.fxml"));
        Scene scene = new Scene(root,900,700);
        Stage stage =(Stage) girisButton.getScene().getWindow();
        stage.setTitle("Kamp Alanı");
        stage.setScene(scene);
        stage.show();
    }

    public void initialize(){
        Image image = new Image("sample/Gorseller/alangirissayfasi.jpg");
        projeGirisImg.setImage(image);
    }
}
