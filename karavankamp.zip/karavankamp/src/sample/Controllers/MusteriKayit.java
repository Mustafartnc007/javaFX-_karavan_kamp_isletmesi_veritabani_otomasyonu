package sample.Controllers;

import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import sample.Aktivite;
import sample.Alan;
import sample.Controllers.KampAlani;
import sample.Musteri;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class MusteriKayit {
    public ImageView logoImg;
    public TextField isimTxt;
    public TextField soyisimTxt;
    public TextField yasTxt;
    public DatePicker girisDate;
    public DatePicker cikisDate;
    public String alantipi;
    private static final String VERITABANI_URL = "jdbc:mysql://localhost:3306/kampkaravan";
    private static final String KULLANICI_ADI = "root";
    private static final String SIFRE = "admin123";
    public TableColumn<Musteri,Integer> idColumn;
    public TableColumn<Musteri,String> alanColumn;
    public TableColumn<Musteri,String> adColumn;
    public TableColumn<Musteri,String> soyadColumn;
    public TableColumn<Musteri,Integer> yasColumn;
    public TableColumn<Musteri,LocalDate> girisColumn;
    public TableColumn<Musteri,LocalDate> cikisColumn;
    public TableView<Musteri> tableTable;
    public Label kamp_alan_label;
    private int aktiviteFiyati;
    public String alanisim;

    @FXML
    public void musteriKaydet() {
        try (Connection connection = DriverManager.getConnection(VERITABANI_URL, KULLANICI_ADI, SIFRE)) {
            String sql = "INSERT INTO musteri (isim, soyisim, yas, giristarihi, cikistarihi,alan,aktivite,ucret) VALUES (?, ?, ?, ?, ?,?,?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            String isim = isimTxt.getText();
            String soyisim= soyisimTxt.getText();
            int yas = Integer.parseInt(yasTxt.getText());
            LocalDate girisTarihi = girisDate.getValue();
            LocalDate cikisTarihi = cikisDate.getValue();
            preparedStatement.setString(1, isim);
            preparedStatement.setString(2, soyisim);
            preparedStatement.setInt(3, yas);
            preparedStatement.setDate(4, java.sql.Date.valueOf(girisTarihi));
            preparedStatement.setDate(5, java.sql.Date.valueOf(cikisTarihi));
            preparedStatement.setString(6,alanisim);
            preparedStatement.setString(7,"Seçilmedi");
            preparedStatement.setInt(8,0);
            preparedStatement.executeUpdate();
            System.out.println("Müşteri başarıyla kaydedildi.");
            List<Musteri> musteriler = tumMusterileriGetir();
            tableTable.getItems().clear();
            tableTable.getItems().addAll(musteriler);
        } catch (SQLException e) {
            System.err.println("Veritabanı hatası: " + e.getMessage());
        }
    }

    public void initialize() throws SQLException {
        Image image = new Image("sample/Gorseller/016cd55479d02832157c5dcceccab37f.jpg");
        logoImg.setImage(image);
        Connection connection = DriverManager.getConnection(VERITABANI_URL,KULLANICI_ADI,SIFRE);
        String sql = "SELECT alanisim FROM alancontrol";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()){
            alanisim = resultSet.getString("alanisim");
        }
        kamp_alan_label.setText(alanisim);
        List<Musteri> musteriler = tumMusterileriGetir();

        tableTable.getItems().clear();
        // Sütunları modelle eşleştir
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        alanColumn.setCellValueFactory(new PropertyValueFactory<>("alnadi"));
        adColumn.setCellValueFactory(new PropertyValueFactory<>("isim"));
        soyadColumn.setCellValueFactory(new PropertyValueFactory<>("soyisim"));
        yasColumn.setCellValueFactory(new PropertyValueFactory<>("yas"));
        girisColumn.setCellValueFactory(new PropertyValueFactory<>("giristarihi"));
        cikisColumn.setCellValueFactory(new PropertyValueFactory<>("cikistarihi"));

        // Verileri TableView'e ekle
        tableTable.getItems().addAll(musteriler);

    }
    public List<Musteri> tumMusterileriGetir() {
        List<Musteri> musteriler = new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(VERITABANI_URL, KULLANICI_ADI, SIFRE)) {
            String sql = "SELECT id, alan, isim, soyisim, yas, giristarihi, cikistarihi, aktivite, ucret FROM musteri";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String alanisim = (resultSet.getString("alan"));
                if (alanisim.startsWith("Ç")){
                    alantipi="Çadır";

                }
                else{
                    alantipi="Karavan";
                }
                Alan alan = new Alan(alantipi,alanisim);
                String isim = resultSet.getString("isim");
                String soyisim = resultSet.getString("soyisim");
                int yas = resultSet.getInt("yas");
                LocalDate girisTarihi = resultSet.getDate("giristarihi").toLocalDate();
                LocalDate cikisTarihi = resultSet.getDate("cikistarihi").toLocalDate();
                String aktivitetipi = (resultSet.getString("aktivite"));
                if (aktivitetipi.equals("atv")){
                    aktiviteFiyati = 100;
                }
                else if(aktivitetipi.equals("surf")){
                    aktiviteFiyati = 200;
                }
                else{
                    aktiviteFiyati = 300;
                }
                Aktivite aktivite = new Aktivite(aktivitetipi,aktiviteFiyati);
                int ucret = resultSet.getInt("ucret");

                Musteri musteri = new Musteri(id, alan, isim, soyisim, yas, girisTarihi, cikisTarihi, aktivite, ucret);
                musteriler.add(musteri);
            }
        } catch (SQLException e) {
            System.err.println("Veritabanı hatası: " + e.getMessage());
        }

        return musteriler;
    }
}
