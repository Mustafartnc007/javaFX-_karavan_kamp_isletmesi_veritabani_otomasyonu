package sample.Controllers;

public class AktiviteSayfasi {
}
