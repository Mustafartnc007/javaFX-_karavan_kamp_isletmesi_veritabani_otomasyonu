package sample.Controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import sample.Alan;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class KampAlani {
    public ImageView kampKrokisiImg;
    public Button kiralaButon;
    public Button c1Button;
    public Button c2Button;
    public Button c3Button;
    public Button c4Button;
    public Button c5Button;
    public Button c6Button;
    public Button c7Button;
    public Button c8Button;
    public Button c9Button;
    public Button c10Button;
    public Button k1Button;
    public Button k2Button;
    public Button k3Button;
    public Button k4Button;
    public Alan selectedAlan;


    @FXML
    public void setC1Button() throws SQLException {
        selectedAlan = new Alan("Çadır","Ç1");
        alanSecici();
    }
    @FXML
    public void setC2Button() throws SQLException {
        selectedAlan = new Alan("Çadır","Ç2");
        alanSecici();
    }
    @FXML
    public void setC3Button() throws SQLException {
        selectedAlan = new Alan("Çadır","Ç3");
        alanSecici();
    }
    @FXML
    public void setC4Button() throws SQLException {
        selectedAlan = new Alan("Çadır","Ç4");
        alanSecici();
    }
    @FXML
    public void setC5Button() throws SQLException {
        selectedAlan = new Alan("Çadır","Ç5");
        alanSecici();
    }
    @FXML
    public void setC6Button() throws SQLException {
        selectedAlan = new Alan("Çadır","Ç6");
        alanSecici();
    }
    @FXML
    public void setC7Button() throws SQLException {
        selectedAlan = new Alan("Çadır","Ç7");
        alanSecici();
    }
    @FXML
    public void setC8Button() throws SQLException {
        selectedAlan = new Alan("Çadır","Ç8");
        alanSecici();
    }
    @FXML
    public void setC9Button() throws SQLException {
        selectedAlan = new Alan("Çadır","Ç9");
        alanSecici();
    }
    @FXML
    public void setC10Button() throws SQLException {
        selectedAlan = new Alan("Çadır","Ç10");
        alanSecici();
    }
    @FXML
    public void setK1Button() throws SQLException {
        selectedAlan = new Alan("Karavan","K1");
        alanSecici();
    }
    @FXML
    public void setK2Button() throws SQLException {
        selectedAlan = new Alan("Karavan","K2");
        alanSecici();
    }
    @FXML
    public void setK3Button() throws SQLException {
        selectedAlan = new Alan("Karavan","K3");
        alanSecici();
    }
    @FXML
    public void setK4Button() throws SQLException {
        selectedAlan = new Alan("Karavan","K4");
        alanSecici();
    }


    @FXML
    public void kiralaButton() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("../GUI/musteri_kayit_formu.fxml"));
        Scene scene = new Scene(root,900,700);
        Stage stage =(Stage) kiralaButon.getScene().getWindow();
        stage.setTitle("Müşteri Kayıt Ekranı");
        stage.setScene(scene);
        stage.show();
    }

    public void initialize(){
        Image image = new Image("sample/Gorseller/kampkrokisi.png");
        kampKrokisiImg.setImage(image);
    }
    public void alanSecici() throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/kampkaravan","root","admin123");
        String sql = "INSERT INTO alancontrol (alanisim) VALUES (?)";
        PreparedStatement preparedStatement = conn.prepareStatement(sql);
        String alanisim = selectedAlan.getAlanAdi();
        preparedStatement.setString(1,alanisim);
        preparedStatement.executeUpdate();
        System.out.println("Alan kaydedildi");
    }
}
